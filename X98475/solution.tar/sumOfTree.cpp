#include <iostream>

using namespace std;

#include "BinaryTree.hpp"

int sumOfTree(BinaryTree<int> t){
	int suma=0;
	if (t.isEmpty()){
		suma=0;
	}
	else{
		suma+=t.getRoot();
		suma+=sumOfTree(t.getLeft());
		suma+=sumOfTree(t.getRight());
	}
	return suma;
}

